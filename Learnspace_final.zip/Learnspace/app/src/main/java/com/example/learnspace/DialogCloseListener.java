package com.example.learnspace;

import android.content.DialogInterface;

public interface DialogCloseListener {

    void handleDialogClose(DialogInterface dialog);
}
